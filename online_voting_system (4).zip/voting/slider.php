<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/SliderCss.css">
</head>
<body>

</body>
</html>
<div id="slider">
	<figure>
<img src="img/e.jpg">
<img src="img/c.png">
<img src="img/a.jpg">
<img src="img/b.jpg">
<img src="img/d.jpg">
    </figure>
</div>
