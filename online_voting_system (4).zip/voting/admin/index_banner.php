
<div class="side-bar" 
            style="background-color:rgba(0, 100, 0, 1); font-size:25px; text-align:center; margin-top:-10px; padding-top:20px; padding-bottom:0px;">

                <a href="#" style="color:white; font-weight:bold; font-size:30px;">University Online Voting System.</a>
                </a>

        <nav class="nav-menue">
            <ul>
                <li>
                    <a href="../index.php">Home</a>
                </li>
                <li><a href="../candidate_path.php">Candidates</a></li>
                <li><a href="../about.php">UNILUSU</a></li>
                <li><a href="../voters.php">Voter List</a></li>
            </ul>
        </nav>
    </div>
					
</div>